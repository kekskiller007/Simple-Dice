﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Threading;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        Variables v = new Variables();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string betstring = Bet.Text;
            if(betstring == "")
            {
                betstring = "1";
                Bet.Text = "1";
            }
            float betnumber = float.Parse(betstring);
            string RollOverString = RollOver.Text;
            if(RollOverString == "")
            {
                RollOverString = "50";
                RollOver.Text = "50";
            }
            float rollOver = float.Parse(RollOverString);

            if(v.Balance < betnumber || betnumber < 1)
            {
                
            } else
            {
                v.Balance -= betnumber;
                var server = new FairDiceRollServer();
                var hash = server.StartSession();
                var roll = server.RollDice("54uh34hjkrewhou5t34iuhIUHGFRWEhiuwIUHEFhiu54hzjferwhiuzu453izuDILSFCBHCvfiuz5iUIZWEUOZFUEUIWeiu57846zfz4zu");
                float numberfloat = roll.Roll;
                string number = Convert.ToString(numberfloat);
                Number.Text = number;
                var key = server.EndSession();
                if(numberfloat > rollOver)
                {
                    float Chance = 100 - rollOver;
                    float Payout = 100 - 5;
                    Payout = Payout / Chance;
                    v.Balance += betnumber * Payout;
                    double balance = Convert.ToDouble(v.Balance);
                    balance = Math.Round(balance, 2);
                    v.Balance = Convert.ToInt32(balance);
                    double PayoutDouble = Convert.ToDouble(Payout);
                    PayoutDouble = Math.Round(PayoutDouble, 2);
                    string Payoutstring = Convert.ToString(PayoutDouble);
                    PayoutX.ForeColor = Color.Green;
                    PayoutX.Text = PayoutDouble + "x";
                } else
                {
                    PayoutX.ForeColor = Color.Red;
                    PayoutX.Text = "X";
                }
                string Balances = Convert.ToString(v.Balance);
                Balancess.Text = "Balance: " + v.Balance;
            }

            

        }

        
        
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
   
        }
    }

    


}
