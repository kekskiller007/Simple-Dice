﻿
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Play = new System.Windows.Forms.Button();
            this.Number = new System.Windows.Forms.Label();
            this.Bet = new System.Windows.Forms.TextBox();
            this.Balancess = new System.Windows.Forms.Label();
            this.RollOver = new System.Windows.Forms.TextBox();
            this.PayoutX = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Play
            // 
            this.Play.Location = new System.Drawing.Point(350, 300);
            this.Play.Name = "Play";
            this.Play.Size = new System.Drawing.Size(100, 30);
            this.Play.TabIndex = 0;
            this.Play.Text = "Play";
            this.Play.UseVisualStyleBackColor = true;
            this.Play.Click += new System.EventHandler(this.button1_Click);
            // 
            // Number
            // 
            this.Number.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Number.Font = new System.Drawing.Font("Source Code Pro Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Number.Location = new System.Drawing.Point(350, 150);
            this.Number.Name = "Number";
            this.Number.Size = new System.Drawing.Size(100, 100);
            this.Number.TabIndex = 2;
            this.Number.Text = "-";
            this.Number.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Number.Click += new System.EventHandler(this.label1_Click);
            // 
            // Bet
            // 
            this.Bet.Location = new System.Drawing.Point(60, 200);
            this.Bet.Name = "Bet";
            this.Bet.PlaceholderText = "Bet";
            this.Bet.Size = new System.Drawing.Size(100, 23);
            this.Bet.TabIndex = 3;
            this.Bet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Balancess
            // 
            this.Balancess.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Balancess.Location = new System.Drawing.Point(60, 40);
            this.Balancess.Name = "Balancess";
            this.Balancess.Size = new System.Drawing.Size(150, 20);
            this.Balancess.TabIndex = 4;
            this.Balancess.Text = "Balance: 100";
            // 
            // RollOver
            // 
            this.RollOver.Location = new System.Drawing.Point(60, 264);
            this.RollOver.Name = "RollOver";
            this.RollOver.PlaceholderText = "Roll Over";
            this.RollOver.Size = new System.Drawing.Size(100, 23);
            this.RollOver.TabIndex = 5;
            this.RollOver.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PayoutX
            // 
            this.PayoutX.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PayoutX.Location = new System.Drawing.Point(350, 100);
            this.PayoutX.Name = "PayoutX";
            this.PayoutX.Size = new System.Drawing.Size(100, 30);
            this.PayoutX.TabIndex = 6;
            this.PayoutX.Text = "X";
            this.PayoutX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.PayoutX);
            this.Controls.Add(this.RollOver);
            this.Controls.Add(this.Balancess);
            this.Controls.Add(this.Bet);
            this.Controls.Add(this.Number);
            this.Controls.Add(this.Play);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Play;
        private System.Windows.Forms.Label Number;
        private System.Windows.Forms.TextBox Bet;
        internal System.Windows.Forms.Label Balancess;
        private System.Windows.Forms.TextBox RollOver;
        private System.Windows.Forms.Label PayoutX;
    }
}

